package com.example.hw3q2

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import org.xmlpull.v1.XmlPullParser

data class FlashcardData(val question: String, val answer: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                FlashcardQuizScreen()
            }
        }
    }
}

@Composable
fun FlashcardQuizScreen() {
    val context = LocalContext.current
    val flashcards = parseFlashcardsXml(context)
    var shuffledCards by remember { mutableStateOf(flashcards) }

    // Shuffle every 15s
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000L)
            shuffledCards = shuffledCards.shuffled()
        }
    }

    LazyRow(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        items(shuffledCards) { card ->
            FlashcardItem(card)
        }
    }
}

@Composable
fun FlashcardItem(card: FlashcardData) {
    var flipped by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .width(300.dp)
            .padding(8.dp)
            .clickable { flipped = !flipped }
    ) {
        Text(
            text = if (flipped) card.answer else card.question,
            modifier = Modifier.padding(16.dp)
        )
    }
}

fun parseFlashcardsXml(context: Context): List<FlashcardData> {
    val result = mutableListOf<FlashcardData>()
    val parser = context.resources.getXml(R.xml.flashcards)
    var eventType = parser.eventType
    var question = ""
    var answer = ""

    while (eventType != XmlPullParser.END_DOCUMENT) {
        if (eventType == XmlPullParser.START_TAG) {
            when (parser.name) {
                "question" -> question = parser.nextText().trim()
                "answer" -> answer = parser.nextText().trim()
            }
        } else if (eventType == XmlPullParser.END_TAG && parser.name == "card") {
            result.add(FlashcardData(question, answer))
        }
        eventType = parser.next()
    }
    return result
}

package com.example.hw3q3

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import org.xmlpull.v1.XmlPullParser

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                TypingSpeedTestScreen()
            }
        }
    }
}

// Parse words from res/xml/typingwords.xml
fun parseWordsXml(context: Context): List<String> {
    val words = mutableListOf<String>()
    val xml = context.resources.getXml(R.xml.typingwords)
    var eventType = xml.eventType

    while (eventType != XmlPullParser.END_DOCUMENT) {
        if (eventType == XmlPullParser.START_TAG && xml.name == "word") {
            words.add(xml.nextText().trim())
        }
        eventType = xml.next()
    }
    return words
}

@Composable
fun TypingSpeedTestScreen() {
    val context = LocalContext.current
    val allWords = parseWordsXml(context)
    // Keep a mutable list of currently displayed words
    val displayedWords = remember { mutableStateListOf<String>() }

    // Track typed text and stats
    var typedText by remember { mutableStateOf("") }
    var typedWordsCount by remember { mutableStateOf(0) }
    val startTime = remember { System.currentTimeMillis() }

    // Populate initial words (e.g., show 5 at a time)
    LaunchedEffect(Unit) {
        displayedWords.addAll(allWords.take(5))
    }

    // Replace any untyped word every 5s
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            // For simplicity, just replace the first untyped word if any
            if (displayedWords.isNotEmpty()) {
                displayedWords.removeAt(0)
                // Grab next word from allWords if available
                val nextIndex = (typedWordsCount + displayedWords.size) % allWords.size
                displayedWords.add(allWords[nextIndex])
            }
        }
    }

    // Handle WPM calculation in real-time
    val currentTime = System.currentTimeMillis()
    val elapsedMinutes = (currentTime - startTime) / 60000f
    val wpm = if (elapsedMinutes > 0) (typedWordsCount / elapsedMinutes) else 0f

    Column(Modifier.padding(16.dp)) {
        Text(text = "WPM: ${wpm.toInt()}")
        OutlinedTextField(
            value = typedText,
            onValueChange = { newValue ->
                typedText = newValue
                // If typed text matches any displayed word, remove it and increment count
                val matchIndex = displayedWords.indexOf(newValue)
                if (matchIndex >= 0) {
                    displayedWords.removeAt(matchIndex)
                    typedWordsCount++
                    typedText = "" // reset input
                    // Add the next word if available
                    val nextIndex = (typedWordsCount + displayedWords.size) % allWords.size
                    displayedWords.add(allWords[nextIndex])
                }
            },
            label = { Text("Type the word") },
            modifier = Modifier.fillMaxWidth()
        )

        // Show the list of words
        Spacer(Modifier.height(16.dp))
        LazyColumn {
            items(displayedWords) { word ->
                Text(text = word, Modifier.padding(8.dp))
            }
        }
    }
}
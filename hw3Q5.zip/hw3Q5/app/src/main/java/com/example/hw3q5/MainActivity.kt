package com.example.hw3q5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                SudokuScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SudokuScreen() {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Flattened 9x9 grid: 81 cells
    val sudokuGrid = remember {
        MutableList(81) { null as Int? }.toMutableStateList()
    }

    var showDialog by remember { mutableStateOf(false) }
    var selectedIndex by remember { mutableStateOf<Int?>(null) }

    fun resetGrid() {
        sudokuGrid.clear()
        // Randomize first row
        val firstRow = (1..9).shuffled()
        sudokuGrid.addAll(firstRow)
        // Rest empty
        repeat(72) { sudokuGrid.add(null) }
    }

    fun isValidPlacement(grid: List<Int?>, index: Int, candidate: Int): Boolean {
        val row = index / 9
        val col = index % 9

        // Check row
        for (c in 0..8) {
            if (grid[row * 9 + c] == candidate) return false
        }
        // Check column
        for (r in 0..8) {
            if (grid[r * 9 + col] == candidate) return false
        }
        // Check 3x3 box
        val boxRow = (row / 3) * 3
        val boxCol = (col / 3) * 3
        for (r in boxRow until boxRow + 3) {
            for (c in boxCol until boxCol + 3) {
                if (grid[r * 9 + c] == candidate) return false
            }
        }
        return true
    }

    fun isGameWon(): Boolean {
        if (sudokuGrid.any { it == null }) return false
        for (index in sudokuGrid.indices) {
            val value = sudokuGrid[index] ?: return false
            sudokuGrid[index] = null
            val valid = isValidPlacement(sudokuGrid, index, value)
            sudokuGrid[index] = value
            if (!valid) return false
        }
        return true
    }

    LaunchedEffect(Unit) {
        resetGrid()
    }

    // Show a SnackBar if puzzle is solved
    LaunchedEffect(sudokuGrid) {
        if (isGameWon()) {
            scope.launch {
                snackbarHostState.showSnackbar("You won!")
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sudoku") },
                actions = {
                    Button(onClick = { resetGrid() }) {
                        Text("Reset")
                    }
                }
            )
        },
        snackbarHost = {
            SnackbarHost(snackbarHostState)
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(9),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(sudokuGrid) { index, value ->
                    val row = index / 9
                    val col = index % 9
                    SudokuCell(
                        number = value,
                        row = row,
                        col = col,
                        onClick = {
                            // Only open if cell is empty
                            if (value == null) {
                                selectedIndex = index
                                showDialog = true
                            }
                        }
                    )
                }
            }

            // Dialog to pick a number (1..9)
            if (showDialog && selectedIndex != null) {
                AlertDialog(
                    onDismissRequest = { showDialog = false },
                    title = { Text("Enter number 1-9") },
                    text = {
                        Column {
                            (1..9).chunked(3).forEach { rowChunk ->
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    for (candidate in rowChunk) {
                                        Button(
                                            onClick = {
                                                if (isValidPlacement(sudokuGrid, selectedIndex!!, candidate)) {
                                                    sudokuGrid[selectedIndex!!] = candidate
                                                }
                                                showDialog = false
                                            },
                                            modifier = Modifier.padding(4.dp)
                                        ) {
                                            Text(candidate.toString())
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showDialog = false }) {
                            Text("Close")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun SudokuCell(number: Int?, row: Int, col: Int, onClick: () -> Unit) {
    // Thicker borders on every 3rd row/col and outer edges
    val topBorderWidth = if (row % 3 == 0) 3.dp else 1.dp
    val leftBorderWidth = if (col % 3 == 0) 3.dp else 1.dp
    val rightBorderWidth = if (col == 8) 3.dp else 1.dp
    val bottomBorderWidth = if (row == 8) 3.dp else 1.dp

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clickable { onClick() }
    ) {
        // Draw borders
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
        ) {
            // Top border
            drawLine(
                color = Color.Black,
                start = this.center.copy(x = 0f, y = 0f),
                end = this.center.copy(x = size.width, y = 0f),
                strokeWidth = topBorderWidth.toPx()
            )
            // Bottom border
            drawLine(
                color = Color.Black,
                start = this.center.copy(x = 0f, y = size.height),
                end = this.center.copy(x = size.width, y = size.height),
                strokeWidth = bottomBorderWidth.toPx()
            )
            // Left border
            drawLine(
                color = Color.Black,
                start = this.center.copy(x = 0f, y = 0f),
                end = this.center.copy(x = 0f, y = size.height),
                strokeWidth = leftBorderWidth.toPx()
            )
            // Right border
            drawLine(
                color = Color.Black,
                start = this.center.copy(x = size.width, y = 0f),
                end = this.center.copy(x = size.width, y = size.height),
                strokeWidth = rightBorderWidth.toPx()
            )
        }

        Text(
            text = number?.toString() ?: "",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}
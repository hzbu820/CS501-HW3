package com.example.hw3q1

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.ui.text.font.FontWeight
import org.xmlpull.v1.XmlPullParser

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val photos = parsePhotosXml(this)
        setContent {
            MaterialTheme {
                StaggeredPhotoGallery(photos)
            }
        }
    }

    private fun parsePhotosXml(context: Context): List<PhotoData> {
        val photos = mutableListOf<PhotoData>()
        val xml = context.resources.getXml(R.xml.photos)
        var eventType = xml.eventType
        var title = ""
        var file = ""

        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG) {
                when (xml.name) {
                    "title" -> title = xml.nextText().trim()
                    "file" -> file = xml.nextText().trim()
                }
            } else if (eventType == XmlPullParser.END_TAG && xml.name == "photo") {
                photos.add(PhotoData(title, file))
            }
            eventType = xml.next()
        }
        return photos
    }
}

@Composable
fun StaggeredPhotoGallery(photos: List<PhotoData>) {
    LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 150.dp)) {
        items(photos) { photo ->
            PhotoItem(photo)
        }
    }
}

@SuppressLint("DiscouragedApi")
@Composable
fun PhotoItem(photo: PhotoData) {
    val context = LocalContext.current
    val isExpanded = remember { mutableStateOf(false) }
    val size by animateDpAsState(
        targetValue = if (isExpanded.value) 250.dp else 150.dp,
        animationSpec = tween(400)
    )

    Box(
        modifier = Modifier
            .padding(4.dp)
            .clickable { isExpanded.value = !isExpanded.value }
    ) {
        Image(
            painter = androidx.compose.ui.res.painterResource(
                id = context.resources.getIdentifier(
                    photo.file.substringBefore('.'),
                    "drawable",
                    context.packageName
                )
            ),
            contentDescription = photo.title,
            modifier = Modifier
                .fillMaxWidth()
                .height(size)
                .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop
        )
        Text(
            text = photo.title,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .background(Color.Black.copy(alpha = 0.4f))
                .padding(4.dp)
        )
    }
}

data class PhotoData(val title: String, val file: String)

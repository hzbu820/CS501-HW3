package com.example.hw3q4

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                InfiniteNumberGrid()
            }
        }
    }
}

@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun InfiniteNumberGrid() {
    val numbers = remember { mutableStateListOf<Int>() }
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }

    // Initial load
    LaunchedEffect(Unit) {
        numbers.addAll(1..30)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Button(
            onClick = {
                // Reset to 1..30
                numbers.clear()
                numbers.addAll(1..30)
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text(text = "Reset")
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(numbers) { index, number ->
                // When we reach the last item, load the next batch
                if (index == numbers.size - 1 && !isLoading) {
                    scope.launch {
                        isLoading = true
                        delay(1000)  // Fake a loading delay
                        val start = numbers.lastOrNull() ?: 0
                        val nextBatch = (start + 1)..(start + 30)
                        numbers.addAll(nextBatch)
                        isLoading = false
                    }
                }
                // Simple cell UI
                Box(modifier = Modifier.padding(16.dp)) {
                    Text(text = number.toString())
                }
            }
        }
    }
}